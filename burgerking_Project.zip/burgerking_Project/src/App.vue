<template>
  <v-app>
    <!-- 메뉴바 -->
    <v-app-bar color="#683a2f" dark height="80" fixed class="mx-auto">
            <v-app-bar-nav-icon @click="drawer = true" class="mx-2" large></v-app-bar-nav-icon>
            <v-toolbar-title @click="$router.push('/')" class="ml-8 mx-3 pointer pl-0"><h1 class="responsive-title" :class="$mq">BURGERKING</h1></v-toolbar-title>
            <v-spacer v-if="$mq === 'phone'"></v-spacer>
            <img src="@/assets/img/logo.png" height="60px">

      <v-spacer v-if="$mq === 'pc'"></v-spacer>
      <v-toolbar-item v-if="$mq === 'pc'">
        <v-btn height="80"  text to="/"><h3>Main</h3></v-btn>
        <v-btn height="80" text to="/menu"><h3>Menu</h3></v-btn>
        <v-btn height="80" text to="/search"><h3>Find Store</h3></v-btn>
        <v-btn height="80" text to="/brand"><h3>Brand Story</h3></v-btn>
        <v-btn height="80" text to="/faq"><h3>FAQ</h3></v-btn>
        <v-btn height="80" text v-for="item in fnGetMenuItems" :key="item.icon" :to="item.to">
          <v-icon>{{ item.icon }}</v-icon>
          <h3>{{ item.title}}</h3>
        </v-btn>
        <!-- 로그인을 하면 로그아웃 버튼 표시하기 -->
        <v-btn height="80" text v-if="fnGetAuthStatus" @click="fnDoLogout">
          <!-- {{ fnGetUser }}님 환영합니다!! -->
           회원님 환영합니다!!
          <v-icon left class="mx-2">mdi-arrow-right-bold-box-outline</v-icon><h3>로그아웃</h3>
        </v-btn>
      </v-toolbar-item>
    </v-app-bar>

    <!-- 햄버거 버튼 눌렀을때 보이는 메뉴바 -->
    <v-navigation-drawer v-model="drawer" absolute temporary style="position:fixed">
      <v-list nav dense>
        <v-list-item-group v-model="group" active-class="deep-purple--text text--accent-4">
           <v-toolbar-title><v-img src="@/assets/img/logo.png" width="50%" class="mx-auto my-5"></v-img></v-toolbar-title>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-home</v-icon>
            </v-list-item-icon>
            <v-list-item to="/"><h4>메 인 화 면</h4></v-list-item>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-food</v-icon>
            </v-list-item-icon>
            <v-list-item to="/menu"><h4>메 뉴 소 개</h4></v-list-item>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-store-24-hour</v-icon>
            </v-list-item-icon>
            <v-list-item to="/search"><h4>매 장 찾 기</h4></v-list-item>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-history</v-icon>
            </v-list-item-icon>
            <v-list-item to="/brand"><h4>브랜드 스토리</h4></v-list-item>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-chat-question-outline</v-icon>
            </v-list-item-icon>
            <v-list-item to="/faq"><h4>고 객 센 터</h4></v-list-item>
          </v-list-item>

          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-lock-open-outline</v-icon>
            </v-list-item-icon>
            <v-list-item to="/joinstart"><h4>회원가입/로그인</h4></v-list-item>
          </v-list-item>
          
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>

  <!-- 라우터 연결부분 -->
  <v-content>
    <v-slide-y-transition mode="out-in">
      <router-view></router-view>
    </v-slide-y-transition>
  </v-content>

  <!-- footer 부분 -->
   <v-footer class="footer" >
    <v-card  color="#2b0200" flat tile class="text-center pt-5" >
      <v-card-text>
        <!-- <v-btn v-for="icon in icons" :key="icon" class="mx-6 white--text" icon>
          <v-icon size="50px">
            {{ icon }}
          </v-icon>
        </v-btn> -->

      <!-- SNS 아이콘 부분  -->
        <v-btn class="mx-5 white--text icon" icon target="blank" href="https:www.facebook.com/burgerkingkorea">
          <v-icon size="45px">
            mdi-facebook
          </v-icon>
        </v-btn>
        <v-btn class="mx-5 white--text icon" icon target="blank" href="https://twitter.com/BurgerKing_KOR">
          <v-icon size="45px">
            mdi-twitter
          </v-icon>
        </v-btn>
        <v-btn class="mx-5 white--text icon" icon target="blank" href="https://www.youtube.com/@burgerking_korea">
          <v-icon size="45px">
            mdi-youtube
          </v-icon>
        </v-btn>
        <v-btn class="mx-5 white--text icon" icon target="blank" href="https://www.instagram.com/burgerkingkorea">
          <v-icon size="45px">
            mdi-instagram
          </v-icon>
        </v-btn>
      </v-card-text>

      <v-card-text class="white--text pt-0">
        본 사이트는 개인프로젝트(VUE) 포트폴리오 사이트입니다. 버거킹과는 무관함을 안내해 드립니다. 이사이트에 사용된 이미지의 저작권은 버거킹에 있으므로, 무단으로 사용할 수 없습니다. 
      </v-card-text>

      <v-divider></v-divider>

      <v-card-text class="white--text">
        {{ new Date().getFullYear() }} — <strong>BURGERKING</strong>
      </v-card-text>
    </v-card>
  </v-footer>
  
  </v-app>
</template>


<script>
  export default {
    name:'App',
    data: () => ({
      // 햄버거 버튼 효과
      drawer: false,
      group: null,
    }),

    // 로그인 회원가입 부분
    computed:{
      fnGetMenuItems(){
        if (!this.fnGetAuthStatus) {
          return [{
            title:'Join&Login',
            icon:'mdi-lock-open-outline',
            to:'/joinstart'
          }]
        } else {
          return [{
            title:'메인페이지',
            icon:'mdi-accout',
            to:'/loginmain'
          }]
        }
      },
      fnGetAuthStatus(){
        return this.$store.getters.fnGetAuthStatus
      }
    },
    methods:{
      fnDoLogout(){
        this.$store.dispatch('fnDoLogout')
      }
    }
   
  }
</script>

<style lang="scss" scoped>

.responsive-title.xs { font-size: 20px; }
.responsive-title.phone { font-size: 28px;}
.responsive-title.pc { font-size: 35px; }


.theme--dark.v-toolbar.v-sheet { background:none; box-shadow:none }
.v-toolbar__content {
    padding: 0px 0px !important;
}

.footer{
  display: block;
}

</style>
