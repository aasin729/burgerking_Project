<template>
    <v-container class="brand">
        <!-- 버거킹 브랜드 소개부분 -->
            <v-row>
            <v-col cols="12" class="text-center mt-10 mx-auto">
                <h1>BRAND STORY</h1>
                <br>
                <h3>버거킹 브랜드 스토리</h3>
            </v-col>
       </v-row>

        <v-card class="mx-auto  mt-10" max-width="1500" >
            <v-img src="@/assets/img/brand1.jpg" height="430px"></v-img>

            <v-card-title class="text-center">
              BRAND PHILOSOPHY
            </v-card-title>

            <v-card-subtitle class="text-center">
              <h2>버거킹의 역사</h2>
            </v-card-subtitle>

            <v-card-actions>
              <v-spacer></v-spacer>

              <v-btn icon @click="show1 = !show1">
                <v-icon>{{ show1 ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
              </v-btn>
            </v-card-actions>

            <v-expand-transition>
              <div v-show="show1">
                <v-divider></v-divider>
                <v-card-text  class="show">
                    세계 최대 QSR(Quick Service Restaurant) 브랜드 중 하나인 버거킹은 1954년 미국 마이애미에서 James W.McLamore와 David Edgerton에 의해 설립되었습니다. 버거킹은 현재 100개 이상의 국가에서 15,000개 이상의 매장을 운영하고 있습니다. 고기를 팬에 굽는 일반 QSR과는 달리, 버거킹은 고기를 직접 불에 구워 조리하는 직화 방식 (Flame-Broiling)으로 담백하고 풍부한 맛과 향, 그리고 정통 햄버거의 풍미를 선보이고 있습니다. 버거킹의 대표 제품인 와퍼(Whopper)는 100% 순 쇠고기 패티와 함께 양상추, 토마토, 양파, 피클 등 4가지 신선한 야채가 어우러진 풍부한 맛으로 전세계 고객에게 사랑 받고 있습니다.
                </v-card-text>
              </div>
            </v-expand-transition>
        </v-card>


        <!-- 버거킹 코리아 소개부분 -->
        <v-card class="mx-auto mt-10" max-width="1500">
            <v-img src="@/assets/img/brand2.jpg" height="430px"></v-img>
        
            <v-card-title class="text-center">
              BURGERKING KOREA
            </v-card-title>
        
            <v-card-subtitle class="text-center">
              <h2>버거킹 코리아</h2>
            </v-card-subtitle>
        
            <v-card-actions>
              <v-spacer></v-spacer>
        
              <v-btn icon @click="show2 = !show2">
                <v-icon>{{ show2 ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
              </v-btn>
            </v-card-actions>
        
            <v-expand-transition>
              <div v-show="show2">
                <v-divider></v-divider>
        
                <v-card-text class="show">
                   버거킹은 지난 1984년 종로점을 오픈하며 한국에 진출한 이래, 차별화된 제품과 개성 있는 매장 인테리어로 지난 38년간 한국 소비자의 사랑을 받아오고 있습니다. “가장 맛있는 햄버거를 제공하는 프리미엄 QSR 브랜드”로 자리매김한 버거킹은 현재 전국 440개(2021년 12월 기준) 매장을 운영하고 있습니다. 좋은 품질의 제품(Quality)과 친절한 서비스 (Service) 그리고 청결한 매장(Cleanliness)은 고객 여러분께 더 큰 만족을 드리고자 노력하는 버거킹의 약속이자 가치입니다. 더욱 풍성하고 맛있는 제품과 정성을 다하는 고객 서비스로 여러분께 더욱 가까이 다가가도록 하겠습니다.
                </v-card-text>
              </div>
            </v-expand-transition>
        </v-card>

        <!-- 버거킹 수상내역 -->
        <v-row>
             <v-col cols="12" class="text-center mt-10 mx-auto">
                 <h1>BURGERKING AWARDS</h1>
                 <br>
                 <h3>버거킹 수상내역</h3>
             </v-col>
        </v-row>
               <!-- 버거킹 어워즈 사진 -->
        <v-row class="awards">
          <v-col cols="11" class="mx-auto">
            <v-img src="@/assets/img/awards.png" alt=""></v-img>
          </v-col>
        </v-row>

        <v-row>
          <v-col cols="10" class="text-center mt-5 mx-auto">
            <v-timeline>
              <v-timeline-item v-for="item in awards" :key="item" color="red lighten-2" large>
                <template v-slot:opposite>
                  <h1> {{ item.year }}</h1>
                </template>
                <v-card class="elevation-2 px-3 py-3">
                  <div class="text-h5 my-5" style="color:#000">
                   <strong>{{ item.intro }}</strong>
                  </div>
                  <v-icon size="30px">mdi-medal</v-icon>
                  <v-icon size="30px">mdi-medal</v-icon>
                  <v-icon size="30px">mdi-medal</v-icon>
                  <div v-for="(content, index) in item.contents" :key="index" style="color:#757575" class="awards">
                      <h4>{{content}}</h4>
                  </div>
                </v-card>
              </v-timeline-item>
            </v-timeline> 
          </v-col>
        </v-row>
    </v-container>
</template>

<script>
  export default {
    data: () => ({
      show1: false,
      show2: false,
      awards: [
        {
          year: '2022',
          intro : '2022년도 수상내역',
          contents: ['한국에서 가장 존경받는 기업1위(한국능률협회컨설팅)', '100대 프렌차이즈브랜드 선정(매일경제신문)', '프리미엄브랜드지수(KS-PBI)패스트푸트 부분 1위(한국표준협회)','FRANCHISEE OF THE YEAR(BURGER KING APAC)', '고객신뢰도 1위 프리미엄 브랜드 선정']
        },
        {
        
          year: '2021',
          intro : '2021년도 수상내역',
          contents: ['2021코리아 프랜차이즈 어워즈(포스브코리아)', '글로벌 지속가능기업100(UN SDGs)', 'DEVELOPER OF THE TEAY2021','프리미엄브랜드지수(KS-PBI)패스트푸트 부분 1위(한국표준협회)','한국에서 가장 존경받는 기업1위(한국능률협회컨설팅)']
        },
        {
          
          year: '2020',
          intro : '2020년도 수상내역',
          contents: ['2020 에피 어워드(Effie Award)코리아 식품 부분 은상', '2019년 서울영상광고제 TV부문 동상 수상','한국에서 가장 존경받는 기업1위(한국능률협회컨설팅)']
        },
        {
          
          year: '2019',
          intro : '2019년도 수상내역',
          contents: ['서울 크리에이티브 페스티벌 동상(서울영상광고제 집행위원회)', 'MARKETER OF THE YEAR 2019']
        },
        {
          
          year: '2018',
          intro : '2018년도 수상내역',
          contents: ['제26회 국민이 선택한 좋은 광고상 OOH부문 좋은 광고상(한국광고주협회)', '웹어워드 코리아 프로모션 통합 대상(한국인터넷전문가협회)', 'MARKETER OF THE YEAR 2018(BURGER KING GLOBAL)']
        },
      ],
    }),
  }
</script>

<style lang="scss" scoped>
.brand{margin-top: 60px;}
.show{ font-size: 18px;
    line-height: 1.8;
    font-weight: bold;
}
.elevation-2{
  strong{
    text-align: center;
  }
.awards{
  padding: 2px 0;
  margin-top: 20px;
}
}
</style>