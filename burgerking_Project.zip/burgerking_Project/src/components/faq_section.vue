<template>
    <v-container>
       <div class="faqinfo1">
            <v-row class="mt-10">
                <v-col cols="12" class="mt-10 faqinfo2">
                    <h1>고객의 의견에 귀 기울입니다</h1>
                    <p>버거킹은 언제나 고객의 의견에 귀 기울이며 <br>더 나은 서비스 이용 경험을 제공하고자 노력하고있습니다.</p>
                    <p>궁금하신 사항이 있거나 문제를 해결하는데 도움이 필요한 경우<br> 아래의 <strong>자주묻는 FAQ</strong>에서 도움을 받으실 수 있습니다.</p>
                </v-col>
            </v-row>
    
            <v-row class="img">
                <v-col cols="10" class="mx-auto">
                  <v-img src="@/assets/img/faq.jpg" alt="" width="700px"></v-img>
                </v-col>
            </v-row>
       </div>

        <v-expansion-panels focusable>
           <v-col cols="11">
                <v-icon size="40px">mdi-message-question-outline</v-icon><h2>제품/품질/서비스 FAQ</h2>
                <br>
                <v-expansion-panel v-for="(item,i) in service" :key="i">
                  <v-expansion-panel-header class="title">
                    {{ item.title }}
                  </v-expansion-panel-header>
                  <v-expansion-panel-content class="content">
                    {{ item.answer }}
                  </v-expansion-panel-content>
                </v-expansion-panel>
           </v-col>

           <v-col cols="11" class="mt-10">
                <v-icon size="40px">mdi-message-question-outline</v-icon><h2>딜리버리 주문 FAQ</h2>
                <br>
                <v-expansion-panel v-for="(item,i) in deliver" :key="i">
                  <v-expansion-panel-header class="title">
                    {{ item.title }}
                  </v-expansion-panel-header>
                  <v-expansion-panel-content class="content">
                    {{ item.answer }}
                  </v-expansion-panel-content>
                </v-expansion-panel>
           </v-col>

           <v-col cols="11" class="my-10">
                <v-icon size="40px">mdi-message-question-outline</v-icon><h2>멤버십 FAQ</h2>
                <br>
                <v-expansion-panel v-for="(item,i) in membership" :key="i">
                  <v-expansion-panel-header class="title">
                     {{ item.title }}
                  </v-expansion-panel-header>
                  <v-expansion-panel-content class="content">
                    {{ item.answer }}
                  </v-expansion-panel-content>
                </v-expansion-panel>
           </v-col>
        </v-expansion-panels>
    </v-container>
    
    
</template>

<script>
    export default {
        data(){
            return{
                service:[
                    {title: "1. 가격은 어떻게 확인이 가능한가요?", answer:" 제품 주문시에 가격을 확인할 수 있으며, 버거킹 가격 정책에 따라 매장 가격과 배달 시 가격은 다르게 책정되어 있습니다." },
                    {title: "2. 주문을 변경,최소하고 싶은데 가능하나요? ", answer:" 완료된 주문의 취소, 변경을 원하시는 경우 0000-0000로 연락 후 가능 여부를 확인받으실 수 있습니다." }
                ],

                deliver:[
                    {title: "1. 대량주문에 대한 제한이 있는가요?", answer:" 대량주문의 경우 매장 상황을 파악한 후 버거킹 딜리버리 콜센터에서 확인 전화를 드리며 확인 전화가 완료 되어야 주문이 접수됩니다. 원재료 및 제품의 생산시간을 고려하여 가능 여부를 안내해드립니다. " },
                    {title: "2. 딜리버리 주문을 미리 예약하고 싶은데요?", answer:" 예약 주문은 현재 시간으로 부터 2시간 이후에 가능합니다." },
                    {title: "3. 매장에서 판매하는 모든 메뉴를 배달하나요?", answer:" 배달이 어려운 일부 디저트 메뉴를 제외하고, 버거킹 매장에서 판매하고 있는 대부분의 제품을 배달해 드리고 있습니다." },
                    {title: "4. 배달 가능한 시간은 어떻게 되는가요?", answer:" 전매장이 동일하게 오전10시에서 오후10시까지 딜리버리 서비스를 제공하고 있습니다. 매장 상황에 따라 배달이 어려운 경우 주문시 안내를 드리고 있으며, 기상 악화시에는 배달 라이더들의 안전을 위해 배달이 중단, 제한, 지연 될 수 있습니다." },
                    {title: "5. 배달 시간이 얼마나 걸리나요?", answer:" 버거킹 딜리버리 서비스의 배달 시간은 기상조건이나 주문량 및 매장 상황에 따라 소요 시간이 다르며, 고객님의 주문 시에 배달 가능한 예상 시간을 미리 안내드리고 있습니다. 안내 드린 시간 내 음식을 제공할 수 있도록 노력하겠습니다." }

                ],

                membership:[
                    {title: "1. 버거킹 멤버십은 어떻게 가입하나요?", answer:" 별도의 멤버십 가입 없이 버거킹 앱 혹은 홈페이지 회원시 자동으로 멤버십으로 등록됩니다. " },
                    {title: "2. 멤버십 적립은 어떻게 하나요?", answer:" 온라인의 경우 버거킹 앱으로 로그인 후 딜리버리 혹은 킹오더 주문을 한 경우에 멤버십 적립되며, 매장에서 주문한 경우 키오스크 혹은 POS주문 시 버거킹 앱 내 멤버십 바코드 인식 혹은 바코드를 인식하지 않더라도 멤버십 쿠폰이 포함된 주문 완료된 건에 한하여 멤버십 적립 됩니다." },
                    {title: "3. 등급별 멤버십 헤택은 어떻게 되나요?", answer:" 매주 업데이트 되는 회원 전용 할인 쿠폰과 승급 시 무료 제품 쿠폰, 생일 축하 쿠폰 등 다양한 혜택을 누리실 수 있습니다." },
                    {title: "4. 멤버십 승급 쿠폰은 어떻게 받을 수 있나요?", answer:" 승급 헤택 쿠폰은 최소 승급 시 1회에 한하여 제공되는 무료 제품 쿠폰으로, 승급 해당 월 1일에 발급되며 하위 등급에 대한 헤택은 합산되어 제공되지 않습니다. " },
                    {title: "5. 멤버십 적립을 깜빡했어요, 어떻게 하나요?", answer:" 주문 완료된 건의 주문 이후 멤버십 적립은 불가능한 점을 양해 부탁드립니다. " }
                ]

            }
        }

    }
</script>

<style lang="scss" scoped>
$phone: "screen and (max-width:1170px)"; 

.faqinfo1{
    display: flex;
    margin-top: 200px;
    margin-bottom: 150px;
       @media #{$phone}{ display: block; margin: 0 10px;}
}
.faqinfo2{ text-align: center;
    h1{ line-height: 1.8; font-weight: 700;
    font-size: 45px;
    color: #773a2c;
    margin-top: 50px;
    line-height: 112.5%;
     @media #{$phone}{ font-size: 30px;} }
    p{margin-top: 40px; line-height: 2; font-size: 1.125rem;
    font-weight: bold; font-size: 23px;
     @media #{$phone}{ font-size: 15px; font-weight: bold;}
    }
}

.title{
    color: #000; font-weight: bold;
    font-size: 20px;
}

.content{
    padding: 10px 0; color: #d72300; font-weight: bold;
    font-size: 20px;
    @media #{$phone}{ font-size: 17px;} 
}



</style>