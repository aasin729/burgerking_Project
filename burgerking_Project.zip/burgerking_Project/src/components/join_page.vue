<template>
    <v-container>
        <v-row class="mt-10">
            <v-col cols="12" class="text-center my-10">
                <div class="joinintro">
                    <h1>환영합니다!!</h1>
                    <h2>이메일주소 혹은 구글 계정으로 간편하게 <strong>회원가입</strong>하세요!</h2>
                </div>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="6" offset="2" class="text-center mx-auto">
                <form @submit.prevent="fnRegisterUser">
                    <v-text-field name="Email" label="이메일" type="email" v-model="sEmail" required></v-text-field>
                    <v-text-field name="Password" label="비밀번호" type="password" v-model="sPassword" required></v-text-field>
                    <!-- 비밀번호 확인이 맞는지 검사하도록 rules 속성 사용 -->
                    <v-text-field name="ConfirmPassword" label="비밀번호 확인" type="password" v-model="sConfirmPassword" required :rules="[fnComparePassword]"></v-text-field>
                    <div class="joinbtn">
                        <v-btn type="submit" block color="#e22219" dark large>버거킹 회원가입</v-btn>
                    </div>        
                    <v-row>
                        <v-col cols="12" class="text-center my-5 mt-10 display-1">
                            <h5  style="color: #868686;">아이디가 이미 있으시다면<br>로그인으로 이동하세요.</h5>
                        </v-col>
                        <v-col cols="12"  class="my-5 text-center">
                            <v-btn to="/loginstart" block color="#512314" dark large>
                                <v-icon left>mdi-key-outline</v-icon>
                                 버거킹 로그인 이동
                            </v-btn>
                        </v-col>
                    </v-row>
                </form>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    export default {
        data() {
            return {
                sEmail:'',
                sPassword:'',
                sConfirmPassword:''
            }
        },
        computed:{
            fnComparePassword(){
                if (this.sPassword == this.sConfirmPassword) return true
                else return '비밀번호가 일치하지 않습니다.'
            }
        },
        methods:{
            fnRegisterUser(){
                if (this.fnComparePassword) {
                    this.$store.dispatch('fnRegisterUser', {
                        pEmail:this.sEmail,
                        pPassword:this.sPassword
                    })
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
$phone: "screen and (max-width:1024px)"; 

.joinintro{
    margin-top: 40px;
    h1{ color: #2e2e2e;;}
    strong{ color: #e22219; }
    h2{ margin-top: 10px;}
    h4{ margin-top: 10px;}
}
.display-1{
    h5{
    @media #{$phone}{ font-size: 16px;}}
}

</style>