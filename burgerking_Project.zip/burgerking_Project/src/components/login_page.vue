<template>
    <v-container class="mt-10">
        <v-row class="mt-10">
            <v-col cols="12" class="text-center my-10">
                <div class="loginintro">
                    <h1>이메일 로그인</h1>
                    <p>가입하신 이메일주소와 비민번호를 입력하세요!</p>
                </div>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="7" offset="2" class="text-center mx-auto">
                <form @submit.prevent="fnDoLogin">
                    <v-text-field v-model="sEmail" name="Email" label="이메일" type="email" required></v-text-field>
                    <v-text-field v-model="sPassword" name="Password" label="비밀번호" type="password" required></v-text-field>
                    <v-btn v-if="!fnGetLoading" type="submit" color="#e22219" dark large>버거킹 로그인</v-btn>
                     <!--  시간지연의 경우 보이게 될 회전 프로그레스 원-->
                    <v-progress-circular v-if="fnGetLoading" indeterminate :width="7" :size="70" colir="grey lighten-1"></v-progress-circular>
                </form>
                    <!-- 오류 메시지가 있을 경우 표시 -->
                    <v-alert class="mt-3" type="error" dismissible v-model="bAlert">
                        {{ fnGetErrMsg }}
                    </v-alert>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    export default {
        data(){
            return{
                sEmail:'',
                sPassword:'',
                bAlert: false 
            }
        },
        methods:{
            fnDoLogin(){
                this.$store.dispatch('fnDoLogin', {pEmail:this.sEmail, pPassword:this.sPassword})
            }
        },
        computed:{
            fnGetLoading(){
                 return this.$store.getters.fnGetLoading;
            },
            fnGetErrMsg(){
                return this.$store.getters.fnGetErrorMessage
            }
        },
        watch:{
            bAlert(pValue){
                if(pValue == false) this.$store.commit('fnSetErrorMessage', '')
            },
            fnGetErrMsg(pMsg){
                if (pMsg) this.bAlert = true;
            }
        }
    }
</script>

<style lang="scss" scoped>
  .loginintro{
    margin-top: 100px;
    h1{ font-size: 45px;}
    p{ margin-top: 30px; font-size: 20px; font-weight: 900;}
 }
</style>