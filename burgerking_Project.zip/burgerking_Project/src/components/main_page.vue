<template>
    <v-container class="mt-10">
        <v-row class="mt-10">
            <v-col cols="12" class="mt-10 text-center">
             <div class="loginintro">
                    <h1>로그인 성공!</h1>
                    <p><strong>YOUR WAY!</strong> 어서오세요 버거킹입니다.</p>
             </div>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="6" offset="1" dark class="mt-2 text-center mx-auto">
                <!-- 구글 로그인인 경우 사진 이미지 정보 표시 -->
                <img v-if="fnGetUser.photoURL" :src="fnGetUser.photoURL" class="avatar_style">
               <div class="userinfo">
                    <h3 class="pt-2 mt-4">{{ fnGetUser.name }}</h3>
                    <p class="pb-2">회원 이메일 : {{ fnGetUser.email }}</p>
               </div>
            </v-col>
            <v-col cols="6" offset="3" class="text-center mt-1">
                <v-btn @click="fnSendPasswordReset" block color="#d72300" large dark>
                    <v-icon>mdi-email</v-icon>
                    비밀번호 재설정하기
                </v-btn>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    import { oFirebaseAuth } from '@/assets/firebase'
    export default {
        methods:{
            fnSendPasswordReset(){
                oFirebaseAuth.sendPasswordResetEmail(this.fnGetUser.email)
                .then(()=>  alert('비밀번호 재설정 메일을 발송했습니다!'))
                .catch((error)=> console.log(error))
            }
        },
        computed:{
            fnGetUser(){
                let oUserInfo = this.$store.getters.fnGetUser
                return oUserInfo
            }
        }
        
    }
</script>

<style lang="scss" scoped>
.avatar_style{
    width: 100px;
    height: 100px;
    border-radius: 50%;
}
  .loginintro{
    margin-top: 80px;
    h1{ font-size: 45px;}
    p{ margin-top: 30px; font-size: 20px; font-weight: 900;}
    strong{color: #d72300; font-size: 30px;}
 }

 .userinfo{
    margin-top: 10px;
    background: #512314;
    color: #fff;
 }

</style>