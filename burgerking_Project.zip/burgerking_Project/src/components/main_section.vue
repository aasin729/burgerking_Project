<template>
  <v-container class="body" style="padding:0;max-width:1900px">
        <v-row class="section1">
            <!-- 메인 슬라이드 화면 -->
            <v-col cols="12" sm="12" xs="12" md="11" class="slide mx-auto py-0">
                <v-carousel cycle hide-delimiter-background show-arrows-on-hover>
                  <v-carousel-item v-for="(slide, i) in slides" :key="i" :src="$mq==='phone' ? slide.src2 : slide.src1 "></v-carousel-item>
                </v-carousel>
            </v-col>
        </v-row>

        <!-- 유튜브 동영상 부분 -->
        <!-- 터미널에서 npm install vue-youtube 설치후, main.js에 youtube import 하기  -->

         <v-row class="section2">
            <v-col cols="12" sm="12" md="11"  class="mx-auto py-0">
              <iframe width="100%" height="600" src="https://www.youtube.com/embed/85jrGITDPHc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </v-col>
         </v-row>

    

        <!-- 아이콘 부분 -->
          <v-row class="section3">
            <v-col cols="12" class="find mx-auto">
              <h1>매장찾기</h1>
              <h3>고객님 주변에 있는 버거킹을 찾아보세요!</h3>
              <v-btn text to="/search" class="findstore"><h2>매장찾기</h2></v-btn>
              <!-- <h2>매장찾기</h2> -->
            </v-col>
            
            <v-col class="icon">
              <v-img src="@/assets/img/icon4.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>집에서 편안하게<br>받을 수 있는<br><strong>딜리버리</strong></p>
            </v-col>
            <v-col class="icon">
              <v-img src="@/assets/img/icon5.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>미리 주문하고<br>픽업가능한<br><strong>킹오더</strong></p>
            </v-col>
            <v-col class="icon">
              <v-img src="@/assets/img/icon6.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>차안에서 빠르게<br>이용할 수 있는<br><strong>드라이브 스루</strong></p>
            </v-col>
            <v-col class="icon">
              <v-img src="@/assets/img/icon7.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>24시간 언제든<br>함께할 수 있는<br><strong>24시간</strong></p>
            </v-col>
            <v-col class="icon">
              <v-img src="@/assets/img/icon8.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>든든한<br>아침을 도와줄<br><strong>아침메뉴</strong></p>
            </v-col>
            <v-col class="icon">
              <v-img src="@/assets/img/icon9.gif" alt="" width="50%" class="mx-auto"></v-img>
              <p>내 차와 함께<br>올 수 있는 <br><strong>주차공간</strong></p>
            </v-col>
           
          </v-row>

          <!-- 와퍼 사진 부분 -->
          <v-row class="section4">
            <v-col cols="11" class="mx-auto">
              <v-img src="@/assets/img/main1.png" alt=""></v-img>
            </v-col>
          </v-row>

          <!-- 버거킹 앱 부분 -->
          <v-row class="section5">
            <v-col cols="12" class="find mx-auto">
              <h1>버거킹 APP(앱) 다운로드</h1>
              <h3>편리한 방법으로 버거킹앱을 다운로드 하세요.</h3>
              <v-col cols="8" class="mx-auto hidden-sm-and-down">
                <v-img src="@/assets/img/delivery.jpg" alt=""></v-img>
              </v-col>
              <v-col cols="11" class="mx-auto hidden-md-and-up">
                <v-img src="@/assets/img/app1.jpg" alt=""></v-img>
              </v-col>
            </v-col>
          </v-row>

          
          <v-row>
                <v-col cols="2" class="mt-10 app1" offset="2">
                    <h1>스토어 다운로드</h1>
                    <p>애플 앱스토어,구글 플레이스토어에서<br>버거킹 앱을 다운로드 해보세요</p>
                </v-col>

                <v-col cols="2" class="app1 my-5 text-center">
                  <v-btn class="app1 white--text my-5" icon target="blank" href="https://play.google.com/store/apps/details?id=kr.co.burgerkinghybrid">
                    <v-img src="@/assets/img/applogo1.png"></v-img>
                  </v-btn>
                    <br>
                  <v-btn class="app1 white--text my-5" icon target="blank" href="https://apps.apple.com/kr/app/apple-store/id1017567032">  
                    <v-img src="@/assets/img/applogo2.png" ></v-img>
                  </v-btn>  
                </v-col>

                <v-col cols="2" class="mt-10 ml-8 app2">
                    <h1>QR코드 다운로드</h1>
                    <p>QR코드를 스캔하여<br>버거킹 앱을 다운로드 해보세요.</p>
                </v-col>

                <v-col cols="2" class="mb-10 app2">
                    <v-img src="@/assets/img/qrcode.png" width="180px" height="180px"></v-img>
                </v-col>
          </v-row>
  </v-container>

</template>


<script>
  export default {
    data () {
      return {
        slides:[
          {src1:"/assets/img/slide1.png", src2:"/assets/img/slide5.png"},
          {src1:"/assets/img/slide2.png", src2:"/assets/img/slide6.png"},
          {src1:"/assets/img/slide3.png", src2:"/assets/img/slide7.png"},
          {src1:"/assets/img/slide4.png", src2:"/assets/img/slide8.png"},
        ]
      }
    },
  }
</script>

<style lang="scss" scoped>
$phone: "screen and (max-width:1024px)"; 

.section1{
  margin-top: 10px;
}

.section3{
  max-width: 1300px;
  margin: 0 auto;
  background: #fff;
}

.slide{
  margin-top: 56px;
}

.find{
  margin-top: 50px;
  text-align: center;
  h1{ margin-bottom: 16px;
     font-size: 3rem;
    line-height: 100%;
    font-weight: 700;
     @media #{$phone}{ font-size: 2rem;}}
  h3{ margin-top: 25px;
   @media #{$phone}{ font-size: 16px;}}
}

.findstore{ background: #d72300;
    border-radius: 25px; color: #fff; 
    width: 180px;
    padding: 20px 0;
    margin: 0 auto;
    margin-top: 50px;
    h2{
      font-size: 25px;
    }
    }

.icon{
  margin-top: 30px; text-align: center;
  p{margin-top: 10px; font-weight: bold; font-size: 16px;
  strong{ color: #d72300; font-weight: 900;
  }
  }
}

.app1{
   @media #{$phone}{ display: none;}

  h1{font-size: 30px;
   @media #{$phone}{display: none;}}
  p{font-size: 16px; padding-bottom: 30px; line-height: 2; font-weight: bold;
  @media #{$phone}{display: none;}}
}

.app2{
  h1{font-size: 30px;}
  p{font-size: 16px; padding-bottom: 30px; line-height: 2; font-weight: bold;}
   @media #{$phone}{display: none;}
}

</style>