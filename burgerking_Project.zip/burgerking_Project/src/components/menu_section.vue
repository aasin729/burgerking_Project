<template>
  <v-col cols="11" class="menu mx-auto">
    <v-card>
      <v-tabs v-model="tab" color="deep-purple-accent-4" align-tabs="center">
        <v-tab :value="1"><h2>와퍼&주니어</h2></v-tab>
        <v-tab :value="2"><h2>치킨&슈프림버거</h2></v-tab>
        <v-tab :value="3"><h2>사이드</h2></v-tab>
        <v-tab :value="4"><h2>음료&디저트</h2></v-tab>
      </v-tabs>
      
      <v-window v-model="tab" class="menuinfo">
        <v-window-item v-for="(category, index) in categories" :key="index" :value="index">
          <v-container fluid>
            <v-row>
                <v-col v-for="item in category" :key="item.src" cols="12" md="4">
                  <v-hover  v-slot="{ hover }">
                    <v-img :src="item.src" :lazy-src="item.src" aspect-ratio="1" width="50%" class="mx-auto">
                       <v-expand-transition>
                          <div v-if="hover" class="iteminfo text-center pt-14 transition-fast-in-fast-out orange darken-2 v-card--reveal text-p white--text" style="height: 100%;">
                            <p>단품 가격 : {{ item.price | formatPrice }}원</p>
                            <p>단품 칼로리 : {{ item.kcal }}Kcal</p>
                            <p>세트 가격 : {{ item.set | formatPrice }}원 </p>
                            <p>세트 칼로리 : {{ item.setkcal }}Kcal</p>
                          </div>
                        </v-expand-transition>
                    </v-img>
                  </v-hover>
                </v-col>
            
            </v-row>
          </v-container>
        </v-window-item>
      </v-window>
    </v-card>
  </v-col>
</template>

<script>
  export default {
    data: () => ({
      tab: null,
      categories:[
        [
          {src:"/assets/img/whopper1.png" ,price:5200, set:7200, kcal:446, setkcal:881,  name:'콰트로 치즈 와퍼 주니어'},
          {src:"/assets/img/whopper2.png" ,price:10100, set:11100, kcal:1035, setkcal:1470, name:'몬스터 엑스'},
          {src:"/assets/img/whopper3.png" ,price:7500, set:9500, kcal:716, setkcal:1151, name:'치즈와퍼'},
          {src:"/assets/img/whopper4.png" ,price:9300, set:10300, kcal:888, setkcal:1323, name:'기네스 콰트로 치즈와퍼'},
          {src:"/assets/img/whopper5.png" ,price:6900, set:8900, kcal:690, setkcal:1125, name:'불고기 와퍼'},
          {src:"/assets/img/whopper6.png" ,price:5200, set:7200, kcal:381, setkcal:816, name:'통새우 와퍼 주니어'},
          {src:"/assets/img/whopper7.png" ,price:9300, set:10300, kcal:778, setkcal:1213, name:'기네스 와퍼'},
          {src:"/assets/img/whopper8.png" ,price:9300, set:10300, kcal:1055, setkcal:1490, name:'몬스터와퍼'},
      ],
        [
          {src:"/assets/img/chickenb1.png" ,price:7000, set:8000, kcal:574, setkcal:1009, name:'비프&슈프림버거'},
          {src:"/assets/img/chickenb2.png" ,price:5000, set:6000, kcal:439, setkcal:874, name:'잔망 루피 슈프림버거' },
          {src:"/assets/img/chickenb3.png" ,price:4600, set:6600, kcal:571, setkcal:1006, name:'롱치킨 버거' },
          {src:"/assets/img/chickenb4.png" ,price:6200, set:7500, kcal:546, setkcal:987, name:'통새우슈림프버거'},
          {src:"/assets/img/chickenb5.png" ,price:3600, set:4900, kcal:467, setkcal:902, name:'바비큐 치킨 버거'},
          {src:"/assets/img/chickenb6.png" ,price:3600, set:4900, kcal:523, setkcal:968, name:'치킨버거'},
      ],
        [
          {src:"/assets/img/side1.png" ,price:2500, kcal:235, name:'프렌치프라이' },
          {src:"/assets/img/side2.png" ,price:3700, kcal:315, name:'코코넛슈림프&스위트칠리소스'},
          {src:"/assets/img/side3.png" ,price:4000, kcal:354, name:'바삭킹8조각+소스'},
          {src:"/assets/img/side4.png" ,price:3200, kcal:280, name:'너겟킹8조각'},
          {src:"/assets/img/side5.png" ,price:2700, kcal:216, name:'어니언링'},
          {src:"/assets/img/side6.png" ,price:2800, kcal:275, name:'크리미모짜볼'},
          {src:"/assets/img/side7.png" ,price:2000, kcal:184, name:'코올슬로'},
          {src:"/assets/img/side8.png" ,price:2500, kcal:286, name:'치즈스틱'},
      ],
        [
          {src:"/assets/img/dessert1.png" ,price:1800, kcal:180, name:'코카콜라'},
          {src:"/assets/img/dessert2.png" ,price:1800, kcal:150, name:'스프라이트'},
          {src:"/assets/img/dessert3.png" ,price:2000, kcal:20, name:'아메리카노'},
          {src:"/assets/img/dessert4.png" ,price:2300, kcal:175, name:'아이스초코'},
          {src:"/assets/img/dessert5.png" ,price:2300, kcal:175, name:'핫초코'},
          {src:"/assets/img/dessert6.png" ,price:1800, kcal:140, name:'미닛메이드 오렌지'},
          {src:"/assets/img/dessert7.png" ,price:2500, kcal:290, name:'선데이 아이스크림'},
          {src:"/assets/img/dessert8.png" ,price:2200, kcal:270, name:'컵 아이스크림'},
        ]
      ],
    }),
         filters:{
            formatPrice(price) {	
            if (!parseInt(price)) { return ""; }	
            if (price > 999) {	
                var priceString = String(price);
                var priceArray = priceString.split("").reverse();	
                var index = 3;	
                while (priceArray.length > index) {	
                priceArray.splice(index, 0, ",");	
                index += 3;	
                }	
                return "￦" + priceArray.reverse().join("");	
            } else {
                return "￦" + price;	
            }
            }
        }




  }
</script>
<style lang="scss" scoped>
$phone: "screen and (max-width:1024px)"; 

  .menu{
    margin: 0 auto;
    margin-top: 100px;
  }

  .v-card--reveal {
  align-items: center;
  bottom: 0;
  justify-content: center;
  opacity: 0.9;
  position: absolute;
  width: 100%;
  p{
    display: block;
  }
}

.menuinfo{
  cursor: pointer;
}
.iteminfo{
  font-weight: bold;
  @media #{$phone}{ font-size: 13px; margin-bottom: 30px; }
}



</style>