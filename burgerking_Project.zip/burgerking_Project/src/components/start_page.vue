<template>
    <v-container class="mt-15">
        <v-row class="mt-10">
            <v-col cols="12" class="text-center mt-10">
              <div class="loginintro">
                    <h1>간편 로그인</h1>
                    <p>이메일 주소 또는 구글 계정으로 간편하게 로그인 하세요!</p>
              </div>
                <!--  시간지연의 경우 보이게 될 회전 프로그레스 원-->
                <v-progress-circular v-if="fnGetLoading" indeterminate :width="7" :size="70" colir="grey lighten-1"></v-progress-circular> 
            </v-col>
            <v-col cols="6" offset="3" class="mt-5">
                <v-btn @click="fnDoGoogleLogin_Popup" height="80" block  color="black" dark large>
                    <v-icon left>mdi-google</v-icon>
                    <h2>구글로그인</h2>
                </v-btn>
            </v-col>
            <v-col cols="6" offset="3" class="mt-5">
                <v-btn to="/login" height="80"  block color="#e22219" dark large>
                    <v-icon left>mdi-email</v-icon>
                    <h2>이메일 로그인</h2>
                </v-btn>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    export default {
        methods:{
            fnDoGoogleLogin_Popup(){
                this.$store.dispatch("fnDoGoogleLogin_Popup")
            }
        },
        computed:{
            fnGetLoading(){
                return this.$store.getters.fnGetLoading;
            }
        }
    }
</script>

<style lang="scss" scoped>
 .loginintro{
    margin-top: 50px;
    h1{ font-size: 45px;}
    p{ margin-top: 30px; font-size: 20px; font-weight: 900;}
 }


</style>