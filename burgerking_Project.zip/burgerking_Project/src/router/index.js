import Vue from 'vue'
import Router from 'vue-router'
import MainSection from '@/components/main_section'
import MenuSection from '@/components/menu_section'
import SearchSection from '@/components/search_section'
import BrandSection from '@/components/brand_section'
import FaqSection from '@/components/faq_section'
import start from '@/components/start_page'
import main from '@/components/main_page'
import login from '@/components/login_page'
import join from '@/components/join_page'
import error from '@/components/error_page'

Vue.use(Router)

export default new Router({
    mode:'history',
    routes:[
        {path:'/', 
        name:'main_section', 
        component:MainSection},

        {path:'/menu', 
        name:'menu_section', 
        component:MenuSection},

        {path:'/search', 
        name:'search_section', 
        component:SearchSection},

        {path:'/brand', 
        name:'brand_section', 
        component:BrandSection,},

        {path:'/faq', 
        name:'faq_section', 
        component:FaqSection,},

        {path:'/loginstart', 
        name:'start_page', 
        component:start},

        {path:'/main', 
        name:'main_page', 
        component:main},

        {path:'/login', 
        name:'login_page', 
        component:login},

        {path:'/joinstart', 
        name:'join_page', 
        component:join},

        {path:'/error', 
        name:'error_page', 
        component:error},


    ]
})