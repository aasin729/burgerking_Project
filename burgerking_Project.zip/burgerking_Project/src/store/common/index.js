export default{
    state: {
        sErrorMessage: '',
        bIsLoading:false
    },
    mutations:{
        // 로그인 처리중 발생한 오류 메세지 저장
        fnSetErrorMessage(state, payload) {
         state.sErrorMessage = payload
        },
        fnSetLoading(state, payload){
            state.bIsLoading = payload
        }
    },
    getters:{
        fnGetErrorMessage: state => state.sErrorMessage,
        fnGetLoading : state => state.bIsLoading
    },
    actions:{

    }

}